package com.safresh.feedback;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;

public class MainActivity extends Activity {
    static final int GREEN=Color.rgb(8,105,62), DARK=Color.rgb(5,76,45), GOLD=Color.rgb(198,160,65), BG=Color.rgb(246,249,246);
    DB db; LinearLayout root, form; EditText code, price, liked, disliked, improve;
    RadioGroup usage, experience, buy, recommend;
    Map<String,RadioGroup> ratings = new LinkedHashMap<>();
    String[] ratingNames={"Washing performance","Foam production","Fragrance","Soap hardness","Bar durability","Price/value","Overall satisfaction"};
    static final int EXPORT_CODE=701;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(DARK); getWindow().setNavigationBarColor(DARK); db=new DB(this); showForm();}

    TextView text(String s,int size,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(DARK); if(bold)t.setTypeface(null,Typeface.BOLD); t.setPadding(0,dp(6),0,dp(6)); return t;}
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),dp(12),dp(18),dp(20));l.setBackgroundColor(BG);return l;}
    void base(String subtitle){root=column(); ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.addView(root);setContentView(sc);
        TextView brand=text("SAFRESH ESSENTIAL",23,true);brand.setTextColor(GREEN);brand.setGravity(Gravity.CENTER);root.addView(brand);
        TextView sub=text(subtitle,15,true);sub.setGravity(Gravity.CENTER);sub.setTextColor(GOLD);root.addView(sub);
        View line=new View(this);line.setBackgroundColor(GOLD);root.addView(line,new LinearLayout.LayoutParams(-1,dp(2)));
    }
    Button button(String label){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(16);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.setMargins(0,dp(8),0,dp(4));b.setLayoutParams(p);return b;}
    EditText input(String hint,boolean number){EditText e=new EditText(this);e.setSingleLine(!hint.startsWith("What"));e.setHint(hint);e.setTextSize(16);e.setPadding(dp(12),dp(8),dp(12),dp(8));if(number)e.setInputType(8194);else if(hint.startsWith("What"))e.setMinLines(2);e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN));return e;}
    void addLabel(String s){root.addView(text(s,16,true));}
    RadioGroup radios(String[] opts){RadioGroup g=new RadioGroup(this);g.setOrientation(RadioGroup.VERTICAL);for(String s:opts){RadioButton r=new RadioButton(this);r.setText(s);r.setTextSize(15);r.setTextColor(DARK);g.addView(r);}return g;}
    String selected(RadioGroup g){if(g==null||g.getCheckedRadioButtonId()==-1)return "";return ((RadioButton)findViewById(g.getCheckedRadioButtonId())).getText().toString();}
    String rating(RadioGroup g){String s=selected(g);return s.isEmpty()?"":s.substring(0,1);}
    void showForm(){
        ratings.clear();base("CUSTOMER PRODUCT FEEDBACK");
        root.addView(text("Thank you for testing SAFRESH ESSENTIAL laundry bar soap. Please share an honest opinion.",15,false));
        addLabel("Customer code (optional)");code=input("Enter customer code (optional)",false);root.addView(code);
        addLabel("How did you use the soap?");usage=radios(new String[]{"Hand washing","Washing machine","Both"});root.addView(usage);
        root.addView(text("RATE EACH ITEM",18,true));
        root.addView(text("1 = Very Poor     2 = Poor     3 = Average\\n4 = Good             5 = Excellent",13,false));
        for(String n:ratingNames){addLabel(n);RadioGroup g=radios(new String[]{"1","2","3","4","5"});g.setOrientation(RadioGroup.HORIZONTAL);for(int i=0;i<g.getChildCount();i++){RadioButton r=(RadioButton)g.getChildAt(i);r.setTextSize(16);r.setPadding(dp(8),0,dp(12),0);}ratings.put(n,g);root.addView(g);}
        addLabel("How would you rate your overall experience?");experience=radios(new String[]{"Excellent","Good","Fair","Poor"});root.addView(experience);
        addLabel("Would you buy this soap again?");buy=radios(new String[]{"Yes","Maybe","No"});root.addView(buy);
        addLabel("Would you recommend it to someone?");recommend=radios(new String[]{"Yes","Maybe","No"});root.addView(recommend);
        addLabel("What price would you consider fair for one bar? (₦)");price=input("Enter amount in Naira",true);root.addView(price);
        addLabel("What did you like most?");liked=input("Your answer",false);root.addView(liked);
        addLabel("What did you dislike?");disliked=input("Your answer",false);root.addView(disliked);
        addLabel("What should we improve?");improve=input("Your suggestion",false);root.addView(improve);
        Button submit=button("SUBMIT FEEDBACK");root.addView(submit);submit.setOnClickListener(v->submit());
        Button owner=button("OWNER DASHBOARD");owner.setBackgroundTintList(android.content.res.ColorStateList.valueOf(DARK));root.addView(owner);owner.setOnClickListener(v->pin());
    }
    void submit(){
        if(selected(usage).isEmpty()||selected(experience).isEmpty()||selected(buy).isEmpty()||selected(recommend).isEmpty()){new AlertDialog.Builder(this).setMessage("Please answer the usage, experience, buy-again and recommend questions.").setPositiveButton("OK",null).show();return;}
        for(String n:ratingNames)if(rating(ratings.get(n)).isEmpty()){new AlertDialog.Builder(this).setMessage("Please rate: "+n).setPositiveButton("OK",null).show();return;}
        db.insert(code.getText().toString().trim(),selected(usage),ratings,selected(experience),selected(buy),selected(recommend),price.getText().toString().trim(),liked.getText().toString(),disliked.getText().toString(),improve.getText().toString());
        new AlertDialog.Builder(this).setTitle("Thank you!").setMessage("Your feedback has been saved. Thank you for helping SAFRESH ESSENTIAL improve.").setCancelable(false).setPositiveButton("NEXT CUSTOMER", (d,w)->showForm()).show();
    }
    void pin(){EditText p=input("Enter owner PIN",true);p.setInputType( numberPassword());new AlertDialog.Builder(this).setTitle("Owner access").setView(p).setNegativeButton("Cancel",null).setPositiveButton("Unlock",(d,w)->{if("2580".equals(p.getText().toString()))showDashboard();else new AlertDialog.Builder(this).setMessage("Incorrect PIN.").setPositiveButton("OK",null).show();}).show();}
    int numberPassword(){return 2|128;}
    void showDashboard(){
        base("OWNER DASHBOARD");
        int total=db.count();double avg=db.average();int yesBuy=db.countYes("buy_again"),yesRec=db.countYes("recommend");
        root.addView(text("TOTAL SUBMISSIONS: "+total,20,true));root.addView(text(String.format(Locale.US,"AVERAGE OVERALL RATING: %.2f / 5",avg),18,true));
        root.addView(text("WILL BUY AGAIN: "+yesBuy,17,true));root.addView(text("WILL RECOMMEND: "+yesRec,17,true));
        Button export=button("EXPORT ALL RECORDS (CSV)");root.addView(export);export.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"SAFRESH_Customer_Feedback.csv");startActivityForResult(i,EXPORT_CODE);});
        root.addView(text("CUSTOMER RECORDS",18,true));
        Cursor c=db.all();if(c.getCount()==0)root.addView(text("No feedback submitted yet.",15,false));
        while(c.moveToNext()){final int id=c.getInt(c.getColumnIndexOrThrow("_id"));String title="Record #"+id+"  •  "+c.getString(c.getColumnIndexOrThrow("created_at"));String detail="Overall: "+c.getString(c.getColumnIndexOrThrow("r_overall"))+"/5   |   Buy again: "+c.getString(c.getColumnIndexOrThrow("buy_again"));Button item=button(title+"\n"+detail);item.setTextSize(13);root.addView(item);item.setOnClickListener(v->record(id));}
        c.close();Button back=button("BACK TO CUSTOMER FORM");root.addView(back);back.setOnClickListener(v->showForm());
    }
    void record(int id){Cursor c=db.one(id);if(!c.moveToFirst())return;String[] cols={"customer_code","usage","r_washing","r_foam","r_fragrance","r_hardness","r_durability","r_value","r_overall","experience","buy_again","recommend","fair_price","liked","disliked","improve","created_at"};String[] labels={"Customer code","Soap use","Washing performance","Foam production","Fragrance","Soap hardness","Bar durability","Price/value","Overall satisfaction","Overall experience","Buy again","Recommend","Fair price (₦)","Liked most","Disliked","Suggested improvement","Submitted at"};StringBuilder s=new StringBuilder();for(int i=0;i<cols.length;i++){s.append(labels[i]).append(": ").append(c.getString(c.getColumnIndexOrThrow(cols[i]))).append("\\n\\n");}c.close();
        new AlertDialog.Builder(this).setTitle("Customer feedback #"+id).setMessage(s.toString()).setPositiveButton("CLOSE",null).setNegativeButton("DELETE",(d,w)->new AlertDialog.Builder(this).setTitle("Delete this record?").setMessage("This cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(x,y)->{db.delete(id);showDashboard();}).show()).show();}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==EXPORT_CODE&&result==RESULT_OK&&data!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(db.csv().getBytes("UTF-8"));Toast.makeText(this,"CSV backup exported successfully.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}}}
    static String csvq(String s){if(s==null)s="";return "\""+s.replace("\"","\"\"")+"\"";}
    class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"safresh_feedback.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE feedback (_id INTEGER PRIMARY KEY AUTOINCREMENT, customer_code TEXT, usage TEXT, r_washing TEXT, r_foam TEXT, r_fragrance TEXT, r_hardness TEXT, r_durability TEXT, r_value TEXT, r_overall TEXT, experience TEXT, buy_again TEXT, recommend TEXT, fair_price TEXT, liked TEXT, disliked TEXT, improve TEXT, created_at TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        void insert(String code,String use,Map<String,RadioGroup> rs,String exp,String buy,String rec,String price,String liked,String disliked,String improve){
            ContentValues v=new ContentValues();v.put("customer_code",code);v.put("usage",use);
            String[] keys={"r_washing","r_foam","r_fragrance","r_hardness","r_durability","r_value","r_overall"};int i=0;for(String k:keys)v.put(k,rating(rs.get(ratingNames[i++])));
            v.put("experience",exp);v.put("buy_again",buy);v.put("recommend",rec);v.put("fair_price",price);v.put("liked",liked);v.put("disliked",disliked);v.put("improve",improve);
            v.put("created_at",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(new Date()));getWritableDatabase().insert("feedback",null,v);
        }
        Cursor all(){return getReadableDatabase().rawQuery("SELECT * FROM feedback ORDER BY _id DESC",null);}
        Cursor one(int id){return getReadableDatabase().rawQuery("SELECT * FROM feedback WHERE _id=?",new String[]{String.valueOf(id)});}
        int count(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM feedback",null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        double average(){Cursor c=getReadableDatabase().rawQuery("SELECT AVG(CAST(r_overall AS REAL)) FROM feedback",null);c.moveToFirst();double n=c.isNull(0)?0:c.getDouble(0);c.close();return n;}
        int countYes(String col){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM feedback WHERE "+col+"='Yes'",null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
        void delete(int id){getWritableDatabase().delete("feedback","_id=?",new String[]{String.valueOf(id)});}
        String csv(){StringBuilder b=new StringBuilder();String[] cols={"_id","customer_code","usage","r_washing","r_foam","r_fragrance","r_hardness","r_durability","r_value","r_overall","experience","buy_again","recommend","fair_price","liked","disliked","improve","created_at"};for(int i=0;i<cols.length;i++){if(i>0)b.append(',');b.append(csvq(cols[i]));}b.append("\\r\\n");Cursor c=all();while(c.moveToNext()){for(int i=0;i<cols.length;i++){if(i>0)b.append(',');b.append(csvq(c.getString(c.getColumnIndexOrThrow(cols[i]))));}b.append("\\r\\n");}c.close();return b.toString();}
    }
}
