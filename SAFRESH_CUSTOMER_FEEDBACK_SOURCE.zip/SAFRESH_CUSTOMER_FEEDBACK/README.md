# SAFRESH CUSTOMER FEEDBACK

Native Android application source project. Minimum Android version: 8.0 (API 26). The app has no INTERNET permission and stores feedback in a local SQLite database.

## Current features
- Offline customer feedback form with required ratings and optional written responses.
- Local, persistent, append-only submissions.
- Owner dashboard protected by initial PIN `2580`.
- Submission count, average overall satisfaction rating, buy-again and recommendation counts.
- Individual record viewing and confirmation before deletion.
- CSV export using Android's document picker (save to Downloads or another folder).

## Build an APK
This environment did not contain the Android SDK or Gradle, so an APK could not be compiled or device-tested here. To build:
1. Install Android Studio on a computer.
2. Open this project folder (`SAFRESH_CUSTOMER_FEEDBACK`).
3. Allow Android Studio to install the Android SDK and Gradle components it requests.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Install on the owner's Android phone
1. Transfer `app-debug.apk` to the phone.
2. Open the APK and allow installation from that file manager if Android asks.
3. Launch **SAFRESH CUSTOMER FEEDBACK**.
4. Hand customers the phone with the feedback form open. Customers do not need to unlock the owner dashboard.
5. Owner dashboard PIN on first install: **2580**. Change this before collecting real customer data (the first release uses a fixed starter PIN).

## Back up records
1. Open **OWNER DASHBOARD** and enter the PIN.
2. Tap **EXPORT ALL RECORDS (CSV)**.
3. Choose Downloads or another folder in the Android file picker.
4. Copy the CSV file to a computer, USB drive or other safe backup location. Open it with Microsoft Excel.
5. Keep more than one backup copy. Uninstalling the app or clearing its storage can erase local records.

## Important verification note
The source is supplied, but no APK build, emulator run, or physical-device test was possible in the current environment because Android build tools were absent. Build and test the APK on Android Studio before using it for live customer research.
